#ifndef CCONTENT_H
#define CCONTENT_H

class CContent
{
    public:
     CContent() {}
     ~CContent() {}



};



#endif //CCONTENT.H
