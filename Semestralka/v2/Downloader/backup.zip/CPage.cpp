#include "CPage.h"

/**
* Prints content of queue m_toDownload
*/
void CPage::print(set<string> & toDownload)
{

    set<string>::iterator iter;
    for(iter=toDownload.begin(); iter!=toDownload.end();iter++)
    {
        cout << (*iter) << endl;
    }
}

/**
* Parsing html to find links
*
* Method searches for keywords specified by argument Needle
* It finds the keyword and extracts the link, which follows
* Extracted link is enqueed to m_toDownload
*
* @param Keyword to look for
*/
void CPage::CParseLinks(const string & Needle, set<string> & toDownload)
{
    unsigned long long int pos = 0;
    string needle=Needle;
    needle+="=\"";
    while(1)
    {
        pos = m_html.find(needle, pos);
        if(pos==string::npos) break;
        pos+=needle.size(); /// pos now marks the index of the start of the link
        string link;

        if(pos>=m_html.size()) return;
        while(m_html[pos]!='"')
        {
            link+=m_html[pos];
            pos++;
        }


        if(link!="/" && isRelative(link))
            toDownload.insert(link);
    }

    print(toDownload);
    cout << endl << endl << endl;
}


bool CPage::isRelative(const string & url)
{
    if(url.substr(0,3)=="www") return false;
    if(url.substr(0,4)=="http") return false;
    else return true;
}
