#ifndef CPAGE_H
#define CPAGE_H

#include <iostream>
#include <string>
#include <set>
using namespace std;

class CPage
{
    public:
     CPage () {};
     CPage (const string & html) : m_html(html) {};
     ~CPage() {};
     string getHtml() const {return m_html;}
     void setHtml(const string & html) {m_html = html;}
     void CParseLinks(const string & needle, set<string> &);
     bool isRelative(const string & url);
     void print(set<string> &);
    private:
     string m_html;
};

#endif //CPAGE_H
