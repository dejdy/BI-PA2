#include<iostream>
#include<string>
#include "CObject.h"

using namespace std;

