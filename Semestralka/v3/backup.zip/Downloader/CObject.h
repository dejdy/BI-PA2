#ifndef COBJECT_H
#define COBJECT_H

#include<string>

using namespace std;

class CObject
{
    public:
        CObject() {}
        virtual ~CObject() {}
//        CObject(const string & host, const string & page) : m_host(host), m_page(page) {}
//        string getPage() const {return m_page;}
        virtual void download(int coutner) = 0;
        //void mkDir(const string & path);

    protected:

};



#endif //COBJECT_H
