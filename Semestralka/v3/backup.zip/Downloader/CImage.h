#ifndef CIMAGE_H
#define CIMAGE_H

class CImage : public CObject
{
    public:
        CImage() {}
        ~CImage() {}
        void download(int counter) {};

    private:

};



#endif //CIMAGE_H

