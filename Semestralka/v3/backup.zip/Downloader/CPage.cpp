#include<fstream>
#include<string>
#include "CPage.h"
#include "CImage.h"
#include "CDownload.h"


/*
void CPage::print()
{
    set<CObject*>::iterator iter;
    cout << m_toDown->size();
    for(iter=m_toDown->begin(); iter!=m_toDown->end();iter++)
    {
        cout << iter-> << endl;
    }
}
*/

void CPage::CParseLinks(const string & Needle, int depth)
{
    unsigned long long int pos = 0;
    string needle=Needle;
    needle+="=\"";
    while(1)
    {
        pos = m_html.find(needle, pos);

        if(pos==string::npos) break;
        pos+=needle.size(); /// pos now marks the index of the start of the link
        string link;

        if(pos>=m_html.size()) return;
        while(m_html[pos]!='"')
        {
            link+=m_html[pos];
            pos++;
        }


                string str = m_page;
                if(str[str.size()-1]!='/') str.append("/");
                if(link[0]=='/') link.erase(0,1);
                str.append(link);


        if(link!="/" && isRelative(link) && (m_downloaded->find(str)==m_downloaded->end()))
        {

            //if((Needle=="href" || Needle=="HREF" || Needle=="href " || Needle=="HREF ") /*&& link.substr(link.size()-4,string::npos)!=".jpg" && link.substr(link.size()-4,string::npos)!=".ico" && link.substr(link.size()-4,string::npos)!=".pdf"*/)
            {


                CPage * newPage = new CPage(m_host, str, m_toDown, m_downloaded);
                pair<CObject*, int> temp;
                temp.first=newPage;
                temp.second=depth;
                m_downloaded->insert(str);
                m_toDown->push(temp);
            }
            /*else
            {
                CImage * newImage =  new CImage();


            }*/
        }
    }

//    print(toDownload);

}


bool CPage::isRelative(const string & url)
{
    if(url.substr(0,3)=="www") return false;
    if(url.substr(0,4)=="http") return false;
    else return true;
}



void CPage::parse(const string & response)
{
    size_t posit = response.find("\r\n\r\n");
    setHeader(response.substr(0, posit));
    setHtml(response.substr(posit+4, string::npos));
}

void mkDir(const string & path)
{
    string newDir;
    newDir="mkdir -p ";
    newDir.append(path);
    system(newDir.c_str());
}


string CPage::fileName()
{
    string path="Downloaded/";
    path.append(m_host);
    path.append(m_page);
    if(m_page=="") path.append("/index");

    if(path[path.size()-1]=='/') path.erase(path.size()-1, 1);
    for(int i=path.size()-1; i>0; i--)
    {
        if(path[i]=='.') break;
        if(path[i]=='/')
        {
            path.append(".html");
            break;
        }
    }
    return path;
}

string CPage::pathName()
{
    string path = "";
    path = "Downloaded/";
    path.append(m_host);
    path.append("/");
    path.append(m_page);

    for(int i=path.size()-1; i>0; i--)
    {
        if(path[i]=='.')
        {
            while(path[i]!='/')
            {
                path[i]='\0';
                i--;
            }
            break;
        }
        if(path[i]=='/') break;
    }
    return path;
}

void CPage::download(int depth)
{
    mkDir(pathName());
    cout << "Downloading: " << m_host << m_page << endl;
string n="Downloaded/";
n.append(m_host);
n.append(m_page);
    CDownload * newDown = new CDownload(m_html);
    parse(newDown->getPage(m_host.c_str(),m_page.c_str(), fileName()));


    CParseLinks("HREF", depth);
    CParseLinks("HREF ", depth);
    CParseLinks("href", depth);
    CParseLinks("href ", depth);
    CParseLinks("src", depth);
    CParseLinks("src ", depth);
    CParseLinks("SRC", depth);
    CParseLinks("SRC ", depth);

/*
    ofstream ofs;
    ofs.open(fileName());
    ofs << m_html;
    ofs.close();
    */
//    cout << m_html;




    delete newDown;
}
