#include <iostream>
#include <string>
#include "CArguments.h"
using namespace std;

CArguments::CArguments()
{

}


CArguments::~CArguments()
{

}


CArguments::CArguments(int argc, char ** argv)
{
    m_argc = argc;
    m_argv = argv;
    parseSite();
    parseTags();
    parsePath();
    parseDepth();
    parseImageOp();
    parseOriginalLinksOp();
}


void CArguments::parseSite()
{
    int i=0;
    string host, page, adress;
    host="";
    page="";
    pair<string, string> url;
    adress = m_argv[m_argc-1];

    if(adress.substr(0,7)=="http://")
        adress=adress.substr(7,string::npos);
    if(adress.substr(0,8)=="https://")
        adress=adress.substr(8,string::npos);

    while(adress[i] && adress[i] != '/')
    {
        host += adress[i];
        i++;
    }

    while(adress[i])
    {
        page += adress[i];
        i++;
    }

    url.first = host;
    url.second = page;

    m_site = url;
}


void CArguments::parseTags()
{
    string arg;
    bool flag=false;
    for(int i=0; i<m_argc-1; i++)
    {
        arg=m_argv[i];
        if(arg=="-t")
        {
            flag=true;
            i++;
        }
        arg=m_argv[i];
        if(arg[0]=='-' && flag)
        {
            return;
        }
        if(flag)
        {
            arg=m_argv[i];
            m_tags.push_back(arg);
        }
    }
    if(m_tags.size()==0)
    {
        m_tags.push_back("href=");
        m_tags.push_back("href =");
        m_tags.push_back("HREF=");
        m_tags.push_back("HREF =");
        m_tags.push_back("src=");
        m_tags.push_back("src =");
        m_tags.push_back("SRC=");
        m_tags.push_back("SRC =");
        m_tags.push_back("url(");
    }
}


void CArguments::parsePath()
{
    int pos = findOption("-o");
    if(pos!=-1) m_path = m_argv[pos+1];
    else m_path = "Downloaded/";;
}


void CArguments::parseDepth()
{
    int pos = findOption("-d");
    if(pos!=-1) m_depth = atoi(m_argv[pos+1]);
    else m_depth = 2;
}


void CArguments::parseImageOp()
{
    int test = findOption("-i");
    if(test==-1) m_saveImages = true;
    else m_saveImages = false;
}


void CArguments::parseOriginalLinksOp()
{
    int test = findOption("-l");
    if(test==-1) m_originalLinks = false;
    else m_originalLinks = true;
}


int CArguments::findOption(const string & option)
{
    string arg;
    for(int i=0; i<m_argc-1; i++)
    {
        arg=m_argv[i];
        if(arg == option)
        {
            return i;
        }
    }
    return -1;
}


pair<string,string> CArguments::getSite() const
{
    return m_site;
}


vector<string> CArguments::getTags() const
{
    return m_tags;
}


string CArguments::getPath() const
{
    return m_path;
}


int CArguments::getDepth() const
{
    return m_depth;
}


int CArguments::getSaveImages() const
{
    return m_saveImages;
}


int CArguments::getOriginalLinks() const
{
    return m_originalLinks;
}
