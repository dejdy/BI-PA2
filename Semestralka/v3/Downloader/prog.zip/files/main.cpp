#include <iostream>
#include <queue>
#include "CDownload.h"
#include "CObject.h"
#include "CPage.h"
#include "CArguments.h"
using namespace std;


int main(int argc, char *argv[])
{
    if(argc<2)
    {
        cout << "Missing argument." << endl;
        return 0;
    }

    set<string> Downloaded;
    queue<pair<CObject*, int> > toDownload;
    pair<CObject*,int> cur;
    CArguments * args = new CArguments(argc, argv);

    CPage * p = new CPage(args->getSite().first, args->getSite().second, &toDownload, &Downloaded, args);

    p->download(0);

    while(toDownload.size()>0)
    {
        cur = toDownload.front();
        if(cur.second>=args->getDepth()) break;
        cout << " ... Num of files in queue: " << toDownload.size() << endl;
        toDownload.pop();
        cur.first->download(cur.second+1);
        delete cur.first;
    }
    cout << " ... Num of files in queue: " << toDownload.size() << endl;
    cout << "... Done!" << endl;

    while(toDownload.size()>0)
    {
        cur = toDownload.front();
        toDownload.pop();
        delete cur.first;
    }

    delete p;
    delete args;
    return 0;
}
