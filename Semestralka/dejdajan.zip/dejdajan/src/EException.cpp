#include <iostream>
#include "EException.h"

using namespace std;

EException::EException()
{

}

EException::~EException()
{

}
