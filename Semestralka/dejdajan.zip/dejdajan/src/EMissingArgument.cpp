#include <iostream>
#include "EMissingArgument.h"

using namespace std;

EMissingArgument::EMissingArgument()
{

}


EMissingArgument::~EMissingArgument()
{

}


void EMissingArgument::Print() const
{
    cout << "Missing argument." << endl;
}
